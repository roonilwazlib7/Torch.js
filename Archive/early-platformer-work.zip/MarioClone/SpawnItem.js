var SpawnItem = function(){};
SpawnItem.prototype.InitSpawning = function()
{
    var that = this;
}
SpawnItem.is(Torch.Sprite);
